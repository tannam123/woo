<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Scan Tables</td>
    <td>
        Select the tables to be updated. This process will update all of the 'Old Settings' with the 'New Settings'. 
        Hold down the 'ctrl key' to select/deselect multiple.
    </td>
</tr>