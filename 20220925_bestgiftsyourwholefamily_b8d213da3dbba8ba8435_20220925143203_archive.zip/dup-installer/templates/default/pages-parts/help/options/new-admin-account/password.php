<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Password</td>
    <td>Password of the user being created.  Must be at least 6 characters long.  Required field when creating a new user.</td>
</tr>