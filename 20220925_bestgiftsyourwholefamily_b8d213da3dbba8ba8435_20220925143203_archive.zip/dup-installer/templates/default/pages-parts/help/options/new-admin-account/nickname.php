<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Nickname</td>
    <td>
        The nickname of the new user will be created. It is optional to create a new user. 
        If you will not fill this nickname, the username will become nickname
    </td>
</tr>