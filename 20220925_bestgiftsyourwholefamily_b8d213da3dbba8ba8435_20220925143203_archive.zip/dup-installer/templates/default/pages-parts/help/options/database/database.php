<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Database</td>
    <td>
        The name of the database to which this installation will connect and install the new tables and data into.  
        Some hosts will require a prefix while others do not.  
        Be sure to know exactly how your host requires the database name to be entered.
    </td>
</tr>